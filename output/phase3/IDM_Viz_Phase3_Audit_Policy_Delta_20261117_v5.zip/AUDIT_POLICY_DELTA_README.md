# IDM-Viz Phase 3 audit-policy delta v5

Apply this additive overlay after extracting the v20 base and the matched-adaptation v3 and audit-policy v4 deltas. It carries their contents forward and updates the audit-policy report to include seed-level paired contrasts against uniform, with each seed averaged over matched conditions and budgets before bootstrap resampling. The report also discloses unequal strict-cap acquisition volume, so episode-count differences are not misrepresented as equal-spend rankings.

The six-policy matrix contains 30,240 policy-seed cells and 725,760 sequential decision records across strict-cap/exact-quota modes, budgets 2/4/8, delays 0/5/20/100, seven synthetic conditions and 30 seeds. Delayed accuracy enters the released-error signal only after `source_batch + delay < decision_clock`. This is outcome-informed cached synthetic replay, not fresh or prospective confirmation; delay 100 exceeds the 24-batch stream horizon.

The final editable TeX and two-page PDF are at `reports/phase3/audit_policy_matrix_20261117_v7/`. Its report receipt hashes the PDF and data summaries. The submitted Phase 2 document and earlier snapshots remain unchanged.
