"""Point the workspace package status record to the latest validated delta."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATUS = ROOT / "output/phase3/IDM_Viz_Phase3_Addendum_Package_Status_20261117.json"
RECEIPT = ROOT / "output/phase3/IDM_Viz_Phase3_Audit_Policy_Delta_20261117_v5.receipt.json"


def main() -> None:
    status = json.loads(STATUS.read_text(encoding="utf-8"))
    receipt = json.loads(RECEIPT.read_text(encoding="utf-8"))
    status["supplementary_delta"] = receipt["package"]
    status["supplementary_delta_receipt"] = RECEIPT.name
    status["supplementary_delta_sha256"] = receipt["sha256"]
    status["supplementary_delta_history"] = [
        "IDM_Viz_Phase3_Matched_Adaptation_Delta_20261117_v3.zip",
        "IDM_Viz_Phase3_Audit_Policy_Delta_20261117_v4.zip", receipt["package"]]
    status["note"] = (
        "Recommended base addendum v20 remains unchanged. Apply matched-adaptation delta v3, "
        "audit-policy delta v4, then v5; v5 carries forward the prior 54-file overlay and includes "
        "the paired-seed analysis, acquisition-volume caveat, and report edition with the PDF hash "
        "in its receipt. CRC and overlay hashes passed. Original Phase 2 and submission archives remain unchanged."
    )
    STATUS.write_text(json.dumps(status, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Updated {STATUS}")


if __name__ == "__main__":
    main()
