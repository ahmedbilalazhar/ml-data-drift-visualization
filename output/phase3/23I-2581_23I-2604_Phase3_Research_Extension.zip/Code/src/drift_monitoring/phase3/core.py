"""Feature-only monitoring. No monitoring function accepts current labels.

Historical labels enter fit_artifacts; monitoring truth belongs to evaluation.py.
All fitted objects are frozen by protocol after historical fitting.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from time import perf_counter
import warnings
import numpy as np
from scipy.special import expit
from scipy.stats import ks_2samp
from sklearn.cluster import MiniBatchKMeans
from sklearn.decomposition import PCA
from sklearn.exceptions import ConvergenceWarning
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler


@dataclass(frozen=True)
class Partition:
    x: np.ndarray
    y: np.ndarray
    ids: np.ndarray


@dataclass(frozen=True)
class FeatureBatch:
    """The entire live scoring interface: deliberately has no label field."""
    x: np.ndarray
    ids: np.ndarray
    seed: int
    condition: str
    batch: int  # one based, also input completion clock


def innovations(seed, stage, n):
    rng = np.random.default_rng(np.random.SeedSequence([int(seed), int(stage)]))
    return rng.normal(size=(n, 8)), rng.random(n)


def baseline_x(z, rho=0.3):
    x = z.copy()
    x[:, 1] = rho * z[:, 0] + np.sqrt(1 - rho**2) * z[:, 1]
    return x


def label_probability(x):
    return expit(1.2*x[:, 0] - 0.9*x[:, 1] + 0.6*x[:, 2])


def historical_partition(seed, stage, n):
    z, u = innovations(seed, stage, n)
    x = baseline_x(z)
    return Partition(x, (u < label_probability(x)).astype(np.int8),
                     seed*1_000_000 + stage*100_000 + np.arange(n))


def monitoring_partition(seed, condition, n=12000, onset=4000, transition_end=6000,
                         return_row=8000):
    """Paired innovations/uniforms; modify X before computing its label law.

    C6: Var(X1)=rho^2+(1-rho^2)=1, Cov(X0,X1)=rho.
    C2 changes X0 while preserving the predeclared construction for X1.
    Row onset is zero based (first changed row is one-based 4001).
    """
    if condition not in [f'C{i}' for i in range(7)]:
        raise ValueError(condition)
    z, u = innovations(seed, 3, n)
    x = baseline_x(z)
    rows = np.arange(n)
    post = rows >= onset
    ramp = np.clip((rows-onset+1) / (transition_end-onset), 0, 1)
    if condition == 'C1':
        x[post, 7] += 1.5
    elif condition == 'C2':
        x[:, 0] += 1.5*ramp
    elif condition == 'C6':
        x[post, 1] = 0.9*z[post, 0] + np.sqrt(1-0.9**2)*z[post, 1]
    p = label_probability(x)
    if condition == 'C3':
        p[post] = 1-p[post]
    elif condition == 'C4':
        p = (1-ramp)*p + ramp*(1-p)
    elif condition == 'C5':
        active = post & (rows < return_row)
        p[active] = 1-p[active]
    ids = seed*1_000_000 + 300_000 + int(condition[1:])*20_000 + rows
    return Partition(x, (u < p).astype(np.int8), ids)


def holm(p):
    p = np.asarray(p, dtype=float)
    order = np.argsort(p, kind='stable')
    adjusted = np.empty_like(p)
    adjusted[order] = np.minimum(1, np.maximum.accumulate(
        p[order] * np.arange(len(p), 0, -1)))
    return adjusted


def poisson_binomial(q):
    q = np.asarray(q, dtype=float)
    if q.ndim != 1 or not np.isfinite(q).all() or np.any((q < 0) | (q > 1)):
        raise ValueError('correctness probabilities must be finite and in [0,1]')
    pmf = np.zeros(len(q)+1)
    pmf[0] = 1
    for j, prob in enumerate(q):
        pmf[1:j+2] = (1-prob)*pmf[1:j+2] + prob*pmf[:j+1]
        pmf[0] *= 1-prob
    # Normalization only removes floating point accumulation error.
    return pmf / pmf.sum()


def harm_kmax(n, reference_correct, reference_n, margin=Fraction(1, 20)):
    """Largest integer K with K/n < reference_accuracy-margin, exactly."""
    threshold = n*(Fraction(int(reference_correct), int(reference_n))-margin)
    return (threshold.numerator-1)//threshold.denominator


def is_harm(correct, n, reference_correct, reference_n):
    return int(correct) <= harm_kmax(n, reference_correct, reference_n)


def impact(q, reference_correct, reference_n):
    pmf = poisson_binomial(q)
    cdf = np.cumsum(pmf)
    cdf[-1] = 1
    n = len(q)
    lo, hi = np.searchsorted(cdf, [0.025, 0.975]) / n
    k = harm_kmax(n, reference_correct, reference_n)
    concern = 0.0 if k < 0 else (1.0 if k >= n else float(cdf[k]))
    return dict(estimate=float(np.mean(q)), lower=float(lo), upper=float(hi),
                concern=concern, concern_flag=concern >= 0.95,
                point_flag=(reference_correct/reference_n-float(np.mean(q))) > 0.05), pmf


def atc_threshold(confidence, correct):
    scores, counts = np.unique(confidence, return_counts=True)
    # Include endpoints, with an upper endpoint that can select zero rows.
    candidates = np.unique(np.r_[0., scores, 1., np.nextafter(1., np.inf)])
    proportions = (len(confidence)-np.searchsorted(np.sort(confidence), candidates,
                                                  side='left'))/len(confidence)
    errors = np.abs(proportions-np.mean(correct))
    return float(candidates[np.flatnonzero(errors == errors.min())[-1]])


@dataclass
class Artifacts:
    scaler: StandardScaler
    model: LogisticRegression
    pca: PCA
    clusters: MiniBatchKMeans
    calibration: IsotonicRegression
    reference_x: np.ndarray
    reference_z: np.ndarray
    reference_correct: int
    reference_n: int
    atc: float
    fit_seconds: float
    fit_ids: dict


def fit_artifacts(seed, train, calibration, reference):
    t = perf_counter()
    ids = [set(p.ids.tolist()) for p in (train, calibration, reference)]
    if any(ids[i] & ids[j] for i in range(3) for j in range(i)):
        raise ValueError('historical partitions overlap')
    scaler = StandardScaler().fit(train.x)
    xt = scaler.transform(train.x)
    model = LogisticRegression(C=1., max_iter=500, random_state=seed)
    with warnings.catch_warnings(record=True) as seen:
        warnings.simplefilter('always', ConvergenceWarning)
        model.fit(xt, train.y)
    if any(issubclass(w.category, ConvergenceWarning) for w in seen):
        raise RuntimeError('LogisticRegression did not converge; no paired seed may be dropped')
    pca = PCA(n_components=3, svd_solver='full').fit(xt)
    clusters = MiniBatchKMeans(n_clusters=3, n_init=3, batch_size=256,
                              random_state=seed).fit(xt)
    cp = model.predict_proba(scaler.transform(calibration.x))[:, 1]
    confidence = np.maximum(cp, 1-cp)
    correctness = ((cp >= .5) == calibration.y).astype(int)
    iso = IsotonicRegression(out_of_bounds='clip').fit(confidence, correctness)
    rx = scaler.transform(reference.x)
    rp = model.predict_proba(rx)[:, 1]
    return Artifacts(scaler, model, pca, clusters, iso, rx[-1000:],
                     pca.transform(rx[-1000:]), int(((rp >= .5) == reference.y).sum()),
                     len(reference.y), atc_threshold(confidence, correctness),
                     perf_counter()-t, dict(train=train.ids, calibration=calibration.ids,
                                           reference=reference.ids))


def score_batch(a: Artifacts, b: FeatureBatch):
    """Score exclusively from historical artifacts, current features and IDs."""
    started = perf_counter()
    if not np.isfinite(b.x).all() or len(b.x) != len(b.ids):
        raise ValueError('invalid feature cohort')
    x = a.scaler.transform(b.x)
    p = a.model.predict_proba(x)[:, 1]
    pred = (p >= .5).astype(np.int8)
    raw = np.maximum(p, 1-p)
    q = a.calibration.predict(raw)
    prediction_s = perf_counter()-started
    t = perf_counter()
    original, latent, messages = [], [], []
    with warnings.catch_warnings(record=True) as seen:
        warnings.simplefilter('always')
        for j in range(8):
            original.append(ks_2samp(a.reference_x[:, j], x[:, j], method='auto'))
        original_s = perf_counter()-t
        t = perf_counter()
        z = a.pca.transform(x)
        for j in range(3):
            latent.append(ks_2samp(a.reference_z[:, j], z[:, j], method='auto'))
        latent_s = perf_counter()-t
        messages = [f'{w.category.__name__}: {w.message}' for w in seen]
    tests = original+latent
    adjusted = holm([v.pvalue for v in tests])
    original_adjusted = holm([v.pvalue for v in original])
    t = perf_counter()
    calibrated, pmf = impact(q, a.reference_correct, a.reference_n)
    calibrated_s = perf_counter()-t
    t = perf_counter()
    uncalibrated, raw_pmf = impact(raw, a.reference_correct, a.reference_n)
    raw_s = perf_counter()-t
    t = perf_counter()
    cluster = a.clusters.predict(x)
    cluster_s = perf_counter()-t
    record = dict(seed=b.seed, condition=b.condition, batch=b.batch,
                  cohort=f'{b.seed}:{b.condition}:{b.batch}', n=len(x),
                  observed_at=b.batch, prediction_phase='before_label_release',
                  reference_correct=a.reference_correct, reference_n=a.reference_n,
                  reference_accuracy=a.reference_correct/a.reference_n,
                  input_alarm=bool(np.any(adjusted <= .05)),
                  original_alarm=bool(np.any(original_adjusted <= .05)),
                  latent_rejection=bool(np.any(adjusted[8:] <= .05)),
                  min_adjusted_p=float(adjusted.min()),
                  min_original_adjusted_p=float(original_adjusted.min()),
                  atc_estimate=float(np.mean(raw >= a.atc)), atc_threshold=a.atc,
                  constant_estimate=a.reference_correct/a.reference_n,
                  prediction_seconds=prediction_s, original_ks_seconds=original_s,
                  latent_ks_seconds=latent_s, calibrated_impact_seconds=calibrated_s,
                  raw_impact_seconds=raw_s, cluster_seconds=cluster_s,
                  ks_warning_count=len(messages))
    for prefix, result in [('cal', calibrated), ('raw', uncalibrated)]:
        record.update({f'{prefix}_{k}': v for k, v in result.items()})
    # Identity baseline is explicit and checked downstream.
    record['calibrated_ac_alone'] = calibrated['estimate']
    ranking = np.argsort([-v.statistic for v in original], kind='stable')
    for j in range(8):
        record.update({f'x{j}_ks': float(original[j].statistic),
                       f'x{j}_p': float(original[j].pvalue),
                       f'x{j}_adjusted_p': float(adjusted[j]),
                       f'x{j}_flag': bool(adjusted[j] <= .05),
                       f'x{j}_rank': int(np.where(ranking == j)[0][0])+1})
    for j in range(3):
        record[f'pc{j}_ks'] = float(latent[j].statistic)
        record[f'pc{j}_adjusted_p'] = float(adjusted[8+j])
        mask = cluster == j
        record[f'cluster{j}_n'] = int(mask.sum())
        record[f'cluster{j}_occupancy'] = float(mask.mean())
        record[f'cluster{j}_q'] = float(q[mask].mean()) if mask.sum() >= 20 else np.nan
    record['score_seconds'] = perf_counter()-started
    cache = dict(ids=b.ids, probability=p, prediction=pred, raw_confidence=raw,
                 correctness_probability=q, pca=z, cluster=cluster,
                 cal_pmf=pmf, raw_pmf=raw_pmf)
    return record, cache, messages
