"""Explicit two-phase clock and scheduled-label boundary, with queue drainage."""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import numpy as np
from sklearn.metrics import f1_score
from .core import is_harm


@dataclass(frozen=True)
class ReleasedLabels:
    batch: int
    available_at: int
    ids: np.ndarray
    labels: np.ndarray


class LabelBroker:
    """Stores evaluator truth; exposes it only at/after scheduled release.

    This is an API boundary, not a security sandbox. The monitor never receives
    this object. IDs must be exact and ordered before a release is accepted.
    """
    def __init__(self, ids, labels, batch_size, delay):
        if delay < 0 or len(ids) != len(labels) or len(ids) % batch_size:
            raise ValueError('invalid release schedule')
        if len(np.unique(ids)) != len(ids):
            raise ValueError('duplicate IDs')
        self.__ids = ids.copy()
        self.__labels = labels.copy()
        self.batch_size = batch_size
        self.delay = delay
        self.batches = len(ids)//batch_size
        self.__released = set()

    def release(self, clock):
        released = []
        for b in range(1, self.batches+1):
            if b+self.delay <= clock and b not in self.__released:
                sl = slice((b-1)*self.batch_size, b*self.batch_size)
                released.append(ReleasedLabels(b, b+self.delay,
                                               self.__ids[sl].copy(), self.__labels[sl].copy()))
                self.__released.add(b)
        return released


def replay(records, prediction_cache, broker):
    """Input rows precede release rows even when d=0; no fake input on drain."""
    events, verification = [], []
    by_batch = {r['batch']: r for r in records}
    for clock in range(1, broker.batches+broker.delay+1):
        if clock <= broker.batches:
            r = by_batch[clock]
            events.append(dict(cohort=r['cohort'], seed=r['seed'], condition=r['condition'],
                               delay=broker.delay, clock=clock, phase=0,
                               event='prediction_persisted', batch=clock))
        for label in broker.release(clock):
            r = by_batch[label.batch]
            cache = prediction_cache[label.batch-1]
            if not np.array_equal(label.ids, cache['ids']):
                raise ValueError('prediction/label ID mismatch')
            correct = int((cache['prediction'] == label.labels).sum())
            row = dict(seed=r['seed'], condition=r['condition'], cohort=r['cohort'],
                       batch=label.batch, delay=broker.delay, available_at=label.available_at,
                       evidence_age_batches=clock-label.batch, n=len(label.ids), correct=correct,
                       accuracy=correct/len(label.ids),
                       harm=is_harm(correct, len(label.ids), r['reference_correct'], r['reference_n']),
                       macro_f1=float(f1_score(label.labels, cache['prediction'], average='macro',
                                              labels=[0, 1], zero_division=0)),
                       class0_n=int((label.labels == 0).sum()), class1_n=int((label.labels == 1).sum()),
                       ids_sha256=hashlib.sha256(label.ids.tobytes()).hexdigest())
            verification.append(row)
            events.append(dict(cohort=r['cohort'], seed=r['seed'], condition=r['condition'],
                               delay=broker.delay, clock=clock, phase=1,
                               event='labels_verified', batch=label.batch))
    if len(verification) != broker.batches:
        raise RuntimeError('release queue not fully drained')
    return events, verification


def as_of(records, verification, clock):
    """UI-ready join; unknown truth is absent, never zero-filled or backdated."""
    visible = {v['cohort']: v for v in verification if v['available_at'] <= clock}
    rows = []
    for record in records:
        if record['observed_at'] > clock:
            continue
        row = record.copy()
        v = visible.get(row['cohort'])
        row.update(verified_accuracy=None if v is None else v['accuracy'],
                   verified_harm=None if v is None else v['harm'],
                   label_status='unresolved' if v is None else 'verified',
                   evidence_age_batches=None if v is None else clock-v['batch'])
        rows.append(row)
    return rows
