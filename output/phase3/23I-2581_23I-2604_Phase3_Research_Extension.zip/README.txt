DATA ANALYSIS AND VISUALIZATION — PHASE 3
Ahmed Bilal (23I-2581) and Umar Behram (23I-2604)

Submission contents: empirical report, figures, offline evidence replay, protocol and decision record, result tables, source code, and validation.
The additional task is synthetic; the local ELEC2 candidate was rejected because chronology could not be verified. No human-subject results are claimed.

This archive is a prepared local artifact. It is not an upload receipt.
