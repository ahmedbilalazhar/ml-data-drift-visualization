# Reproduction notes

The locked final run used 30 matched seeds on the original synthetic task and 30 fresh seeds on the XOR synthetic task. Exact interpreter and package versions are in `Environment.json`; protocol and stop rules are in `Protocol.md`.

The archive contains result tables and source. A full rerun of the matched original-task extension also requires the preserved Phase 2 project and the original run caches; the compact submission intentionally omits large instance caches. From the original workspace root, use the commands documented in the project reproduction guide.

Online predictions, scheduled verification, and evaluator truth are separate. The replay filters truth by its recorded availability clock.
