# IDM-Viz Phase 3 audit-policy delta v4

Apply this additive overlay after extracting the v20 base addendum. It also carries forward the matched-adaptation v3 overlay. It adds a complete declared delayed-audit policy matrix and its editable report, figures, data, tests, and updated Phase 3 audit registry.

The matrix evaluates six policies, strict-cap and exact-quota modes, budgets 2/4/8 cohorts, delays 0/5/20/100, seven synthetic conditions and 30 locked seeds. It records 30,240 policy-seed cells and 725,760 decisions. Labels first affect a decision only when source batch + delay < current clock. The replay uses cached predictions and is outcome-informed for scoring; it is not fresh independent or prospective confirmation. Delay 100 exceeds the 24-batch stream horizon. Exact-quota force-fills and unused strict-cap budgets are reported separately.

The report PDF is `reports/phase3/audit_policy_matrix_20261117_v3/audit_policy_matrix.pdf`; the editable source and vector/raster plots are adjacent. Raw per-seed data, every decision, summaries, paired bootstrap intervals and a protocol lock are under `results/phase3/audit_policy_matrix_20261117_v1/`.

The submitted Phase 2 DOCX and prior submission snapshots are preserved. This is a post-deadline, versioned improvement.
