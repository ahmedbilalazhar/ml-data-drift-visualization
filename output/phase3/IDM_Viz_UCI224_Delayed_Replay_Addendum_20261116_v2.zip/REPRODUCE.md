# UCI 224 delayed-label replay addendum

This package follows the validated Day 3 external-evaluation improvement report. It preserves the frozen batch-1 classifier and source run, adds a label-safe cohort-clock recalibration replay at delays 0/1/2, and corrects batch-1 source/evaluation class metadata with explicit denominators.

From this extracted root, with the configured Anaconda environment:

```powershell
$python = 'C:/Users/hp/anaconda3/python.exe'
& $python -m pytest tests/phase3/test_uci224_delayed_replay.py tests/phase3/test_uci224_metadata_semantics.py -q
& $python scripts/evaluate_uci224_day2.py --out results/phase3/metadata_NEW
& $python scripts/run_uci224_delayed_replay.py --source-run results/phase3/external_uci224_day2_v2 --out results/phase3/replay_NEW
& $python scripts/evaluate_uci224_delayed_replay.py --run results/phase3/replay_NEW
& $python scripts/report_uci224_delayed_replay.py --run results/phase3/replay_NEW --out reports/replay_NEW
tectonic reports/replay_NEW/REPORT.tex --outdir reports/replay_NEW --keep-logs
```

Every output directory must be new. Release eligibility is `source_batch + delay < forecast_batch`; labels from the target cohort never enter its own forecast. The replay uses simulated whole-cohort delays over one ordered data sequence, not observed label-arrival timestamps. Read the protocol and report for denominators and claim limits. `MEMBER_SHA256.json` inventories all packaged files; the adjacent receipt records fresh clean-extraction runs and protected Phase 2 hashes.
