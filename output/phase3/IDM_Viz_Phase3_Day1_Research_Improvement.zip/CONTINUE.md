# Continuation checkpoint

Current state: Day 1 report source, bibliography, findings, demonstration guide, and figures are in this directory. A PDF has been produced with Tectonic 0.17.0; page rendering/inspection and clean extraction checks remain to be completed. Existing source run receipts are historical evidence and were not rerun in this pass.

## Next actions

1. Render every page of `REPORT.pdf` to PNG with bundled `pypdfium2`; visually inspect all pages and fix any clipping, overlaps, or unreadable elements.
2. Check page count/text extraction, citations, broken references, and warnings. Refresh the PDF after fixes.
3. Save the manifest and preservation hashes using the current exact files; copy the complete existing research archive into the Day 1 package as the implementation/results payload.
4. Create a separately named Day 1 ZIP, extract it to a new temporary directory, check CRCs and internal file hashes, and confirm the included report and source are readable. Never replace any existing archive.
5. Recompute hashes of the submitted DOCX, submitted archive, source documents, and historic archives; compare to baseline.
6. Record actual checks and failures in `VALIDATION.md` and `CHECKPOINT.md`.

## Commands

```powershell
tectonic docs/phase3/research_improvement_day1/REPORT.tex --outdir docs/phase3/research_improvement_day1 --keep-logs
```

Use the bundled runtime Python executable noted in `docs/phase3/REPRODUCTION.md` for PDF page rendering. Full study reproduction commands are in `docs/phase3/23I-2581_23I-2604_Phase3_Reproduction.md` and the adaptation reproduction script.
