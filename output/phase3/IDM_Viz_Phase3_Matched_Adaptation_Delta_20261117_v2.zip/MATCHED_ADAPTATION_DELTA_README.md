# Matched adaptation schedule delta

This overlay supplements `IDM_Viz_Phase3_PostDeadline_Addendum_20261117_v20.zip`; it is not a replacement for that archive. Extract the delta over the extracted v20 package to add the matched-clock, matched-feedback-row global versus cluster-local adaptation study.

The study contains 30 paired seeds, stationary and abrupt conditional-reversal streams, and label delays 0/5/20. Global and local arms share the same latest released row-ID windows at clocks 25, 49, 73 and 89. Each opportunity allows 2,000 fit rows; repeated uses count toward 8,000 total adaptation-row uses. Initial training is reported separately. Labels obey `source_batch + delay < forecast_batch`.

On the tested reversal generator both refit policies improve mean accuracy over frozen by about 22 percentage points. Global refitting is higher than local refitting by 0.08, 0.11 and 0.10 percentage points at delays 0/5/20; paired 95% seed-bootstrap intervals exclude zero. Under stationarity, both refit policies slightly reduce accuracy versus frozen. The conclusions are limited to this task, model, partition, delay set and schedule.

Reproduce from the workspace root:

```powershell
python scripts/run_matched_adaptation_schedule.py
python scripts/report_matched_adaptation_schedule.py --run results/phase3/matched_adaptation_schedule_20261117_v1 --out reports/phase3/matched_adaptation_schedule_20261117_v1
tectonic -X compile reports/phase3/matched_adaptation_schedule_20261117_v1/matched_adaptation_schedule.tex --outdir reports/phase3/matched_adaptation_schedule_20261117_v1
python -m pytest -p no:cacheprovider tests/phase3/test_matched_adaptation_schedule_contract.py -q
```

The base v20 archive, Phase 2 submission, implementation brief and original submission archive are preserved unchanged. The Phase 2 DOCX SHA-256 recorded in the audit is `786d4f23d54d0d09edd5f94740198f43ca3b406eb38626ae754fe04fe26c5ef4`.
