# Large-seed robustness and remaining failure modes

**Ahmed Bilal (23I-2581) and Umar Behram (23I-2604)**  
Data Analysis and Visualization · Phase 3 supplementary experiment

**Protocol status:** Outcome-informed robustness replication. It reuses the frozen synthetic task laws and analysis settings; it is not external validation and not a preregistration preceding the earlier studies.

## Why this experiment was run

The main remaining sampling weakness was that model sensitivity and the XOR task had 30 final seeds each. This run adds 1,500 fresh seeds per task (3,000 task-seed replications total), holding the generators, partitions, models, calibrators, thresholds, conditions and batch sizes fixed. It tests seed sensitivity; it does not widen the data domains.

## Design and integrity

The original synthetic task has seven conditions and XOR has five. Each has 12,000 monitoring rows in 24 batches of 500. Logistic regression and the fixed depth-6 tree share each stream; their own historical references define their own realised-harm targets. Harm counts alone therefore do not rank the learners; paired accuracy and estimation error are also reported on identical cohorts. Thresholds or seeds were not selected from results. The online table contains no labels, accuracy, F1 or harm; evaluator metrics are stored separately and joined after each batch score is written. This scale run stores aggregate batch outputs and deterministically regenerated inputs rather than per-instance caches.

The run covers 864,000 online batch records and 864,000 evaluator batch records. Exact strict harm boundaries, unique row keys, model pairing, common input alarms, calibrated-estimate identity and finite scores passed validation. Paired uncertainty uses 2,000 bootstrap replicates over complete seeds.
Analysis record: A post-start output-label correction preserves the metric name in paired-bootstrap rows; it does not change metrics, resampling, run data, predictions or conditions.

## Model sensitivity

![Paired model accuracy differences](paired_accuracy.png)

Positive accuracy differences favor the tree on the matched cohort. Intervals are seed-bootstrap intervals; they do not treat individual batches as independent. Refer to `paired_model_bootstrap.csv` for all conditions and metrics.

| Cohort | Model | Accuracy [95% seed interval] | Calibrated MAE [95% seed interval] | Coverage [95% seed interval] | Calibrated width [95% seed interval] |
|---|---|---:|---:|---:|---:|
| stationary original | logistic | 0.7230 [0.7228, 0.7232] | 0.0169 [0.0168, 0.0171] | 0.9270 [0.9236, 0.9302] | 0.0743 [0.0743, 0.0744] |
| stationary original | shallow tree | 0.6938 [0.6934, 0.6941] | 0.0178 [0.0177, 0.0180] | 0.9251 [0.9218, 0.9284] | 0.0779 [0.0778, 0.0779] |
| conditional-only original | logistic | 0.4257 [0.4255, 0.4259] | 0.3028 [0.3024, 0.3032] | 0.3103 [0.3086, 0.3119] | 0.0743 [0.0743, 0.0744] |
| conditional-only original | shallow tree | 0.4356 [0.4354, 0.4359] | 0.2641 [0.2636, 0.2646] | 0.3085 [0.3068, 0.3102] | 0.0779 [0.0778, 0.0779] |
| dependence original | logistic | 0.6722 [0.6720, 0.6724] | 0.0186 [0.0184, 0.0189] | 0.9164 [0.9126, 0.9203] | 0.0791 [0.0791, 0.0791] |
| dependence original | shallow tree | 0.6363 [0.6360, 0.6367] | 0.0326 [0.0322, 0.0331] | 0.6789 [0.6705, 0.6877] | 0.0804 [0.0803, 0.0804] |
| stationary XOR | logistic | 0.5004 [0.4999, 0.5009] | 0.0198 [0.0196, 0.0200] | 0.9292 [0.9259, 0.9324] | 0.0874 [0.0874, 0.0874] |
| stationary XOR | shallow tree | 0.7022 [0.6936, 0.7103] | 0.0162 [0.0160, 0.0165] | 0.9279 [0.9246, 0.9311] | 0.0713 [0.0706, 0.0720] |
| conditional-only XOR | logistic | 0.4997 [0.4994, 0.4999] | 0.0225 [0.0221, 0.0230] | 0.8880 [0.8813, 0.8941] | 0.0874 [0.0874, 0.0874] |
| conditional-only XOR | shallow tree | 0.4327 [0.4299, 0.4353] | 0.2771 [0.2667, 0.2879] | 0.4567 [0.4440, 0.4692] | 0.0713 [0.0706, 0.0720] |
| label-noise XOR | logistic | 0.5002 [0.4998, 0.5005] | 0.0202 [0.0200, 0.0204] | 0.9225 [0.9190, 0.9260] | 0.0874 [0.0874, 0.0874] |
| label-noise XOR | shallow tree | 0.6181 [0.6130, 0.6231] | 0.0926 [0.0892, 0.0959] | 0.5276 [0.5133, 0.5422] | 0.0713 [0.0705, 0.0721] |

| Cohort | Tree minus logistic accuracy [95% paired seed interval] |
|---|---:|
| stationary original | -0.0292 [-0.0295, -0.0289] |
| conditional-only original | 0.0099 [0.0097, 0.0101] |
| dependence original | -0.0359 [-0.0363, -0.0355] |
| stationary XOR | 0.2018 [0.1935, 0.2101] |
| conditional-only XOR | -0.0670 [-0.0697, -0.0643] |
| label-noise XOR | 0.1179 [0.1129, 0.1226] |

<!-- PAGE -->
## Estimation and interval behavior

![Calibration error and interval coverage](estimation_and_coverage.png)

Coverage is shown against the nominal 95% reference and with seed uncertainty; widths are in the result tables. Coverage shortfall is not repaired by lower alert burden. These are plug-in intervals, not guarantees under arbitrary shift; concern scores are not calibrated harm probabilities, and no flag is not a safety verdict. Concern counts and unflagged harmful batches are reported in the per-seed summaries.

## Input alarms and conditional-only failures

`input_detection_summary.csv` reports per-condition seed denominators and alarm frequencies. For synthetic input-shift conditions C1/C2/C6 and X1/X2, onset matching is defined only over batches 9–12. Conditional-only conditions C3/C4 and X3/X4 keep the input stream unchanged by construction, so an input-only detector has no input-distribution signal for their label changes. A lack of alarm in these cases does not mean low model impact or safety.

| Task / condition | Programmed input event | Seeds | Detected in batches 9-12 | Null batches/seed | Null alerts per 1,000 null batches |
|---|---|---:|---:|---:|---:|
| v1_synthetic/C0 | no | 1500 | not defined (no input event label) | 24 | 42.750 |
| v1_synthetic/C1 | yes | 1500 | 1500/1500 | 8 | 42.083 |
| v1_synthetic/C2 | yes | 1500 | 1500/1500 | 8 | 42.083 |
| v1_synthetic/C3 | no | 1500 | not defined (no input event label) | 24 | 42.750 |
| v1_synthetic/C4 | no | 1500 | not defined (no input event label) | 24 | 42.750 |
| v1_synthetic/C5 | no | 1500 | not defined (no input event label) | 24 | 42.750 |
| v1_synthetic/C6 | yes | 1500 | 563/1500 | 8 | 42.083 |
| xor_synthetic/X0 | no | 1500 | not defined (no input event label) | 24 | 43.250 |
| xor_synthetic/X1 | yes | 1500 | 1500/1500 | 8 | 44.500 |
| xor_synthetic/X2 | yes | 1500 | 1500/1500 | 8 | 44.500 |
| xor_synthetic/X3 | no | 1500 | not defined (no input event label) | 24 | 43.250 |
| xor_synthetic/X4 | no | 1500 | not defined (no input event label) | 24 | 43.250 |

| Conditional-only cohort | Model | Seeds | Harmful batches/seed | Flags/seed | Harm missed/seed |
|---|---|---:|---:|---:|---:|
| v1_synthetic/C3 | logistic | 1500 | 16.08 | 0.00 | 16.08 |
| v1_synthetic/C3 | shallow tree | 1500 | 16.12 | 0.00 | 16.12 |
| v1_synthetic/C4 | logistic | 1500 | 15.69 | 0.00 | 15.69 |
| v1_synthetic/C4 | shallow tree | 1500 | 15.62 | 0.00 | 15.62 |
| xor_synthetic/X3 | logistic | 1500 | 1.05 | 0.00 | 1.05 |
| xor_synthetic/X3 | shallow tree | 1500 | 12.30 | 0.00 | 12.30 |
| xor_synthetic/X4 | logistic | 1500 | 0.61 | 0.00 | 0.61 |
| xor_synthetic/X4 | shallow tree | 1500 | 10.42 | 0.00 | 10.42 |

The earlier C3–C5 misses and v1 calibration results remain part of the evidence; this fresh-seed run can show how consistently those failures recur under the same generators. It cannot identify a universal cause. A plausible explanation remains source-law confidence transfer under conditional change; the experiments measure the failure pattern, not a unique causal mechanism.

## What this adds and what it does not

It narrows Monte Carlo uncertainty for two existing synthetic task families and tests whether the 30-seed model/calibration/alert findings persist over fresh streams. It does not add a natural data source, new learner, alternative adaptive mechanism, human evaluation, causal explanation or external-domain evidence. The XOR task is another controlled synthetic task. RQ3 analyst benefit remains unanswered.

## Reproduction

From the workspace root, use fresh output paths:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass `
  -File .\scripts\reproduce_phase3_large_seed.ps1 `
  -RunDir results/phase3/large_seed_robustness_reproduction `
  -ReportDir reports/phase3/large_seed_robustness_reproduction
```

Exact package versions and source hashes are stored in the run directory. Existing v1/v2/adaptation outputs and prepared archives remain unchanged.

Five-seed sample: 2,880 online rows and 2,880 evaluator rows checked. Discrete fields matched exactly; floats passed allclose (rtol=1e-12, atol=1e-14; max absolute difference 1.11e-16). Timing fields were excluded.

