# IDM-Viz Phase 3 ADWIN baseline delta v6

This is a versioned post-deadline addendum overlay on base package v20. It carries forward the previous matched-adaptation and audit-policy improvements and adds a canonical River ADWIN baseline under the same cached predictions, sampled 500-row audit cohorts, delays, budgets, 30 seed bank, seven synthetic conditions, and strict-cap/exact-quota rules.

ADWIN consumes row-level binary errors only from selected cohorts after `source_batch + delay < decision_clock`. It uses River 0.27.0, delta 0.002, clock 1, and the documented default bucket/window/grace settings. In 5,040 policy cells it fired at least once in 212, all exact-quota cells; it did not fire under strict caps after the single initial probe. This exposes a sparse-feedback deadlock for this policy. It does not establish general ADWIN weakness or superiority of IDM-Viz.

The two-page editable report and compiled PDF are in `reports/phase3/adwin_audit_baseline_20261117_v3/`. Its receipt includes the PDF hash. The input Phase 2 document and historical submission archives are preserved.
