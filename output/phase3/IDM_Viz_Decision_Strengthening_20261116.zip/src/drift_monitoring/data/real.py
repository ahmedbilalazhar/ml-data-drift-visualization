"""Real-data loader (P1-4): elec2 / covtype-subset / weather-pending.

Single entry point so scripts stop re-implementing splits. Contract:
- event_id ascending = replay order (elec2 chronological; covtype constructed;
  weather MUST be verified before ADMIT).
- returns frame + 20/20/60 chronological splits + numeric cols + manifest meta.
- weather without materialized parquet raises PendingAcquisition (never silent).
"""
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
PROC = ROOT / "data" / "processed"
MAN = ROOT / "data" / "manifests"

FILES = {
    "elec2": ("elec2_ordered.parquet", "elec2_manifest.json"),
    "covtype_subset": ("covtype_subset100k.parquet", "covtype_subset_manifest.json"),
    "weather": ("weather_ordered.parquet", "weather_manifest.json"),
}


class PendingAcquisition(RuntimeError):
    pass


def load_real(name: str, drop_like: tuple = ("date",)) -> dict:
    if name not in FILES:
        raise KeyError(f"unknown dataset {name!r}; choose from {sorted(FILES)}")
    pq, mf = FILES[name]
    p, m = PROC / pq, MAN / mf
    if not p.exists():
        raise PendingAcquisition(
            f"{name}: {pq} not materialized. "
            f"{'See configs/datasets/weather.yaml (MOA primary, OpenML toy rejected).' if name == 'weather' else 'Run scripts/download_datasets.py.'}")
    df = pd.read_parquet(p).sort_values("event_id").reset_index(drop=True)
    for c in df.columns:
        if isinstance(df[c].dtype, pd.CategoricalDtype):
            df[c] = df[c].cat.codes.astype(float)
    feats = [c for c in df.columns if c not in ("event_id", "label")
             and not any(d in c.lower() for d in drop_like)]
    num = [c for c in feats if pd.api.types.is_numeric_dtype(df[c])]
    n = len(df)
    splits = {"train": [0, int(n * 0.2) - 1],
              "calib": [int(n * 0.2), int(n * 0.4) - 1],
              "test": [int(n * 0.4), n - 1]}
    meta = json.loads(m.read_text()) if m.exists() else {"dataset": name,
                                                         "manifest": "missing"}
    return {"frame": df, "numeric": num, "splits": splits, "meta": meta,
            "n": n}
