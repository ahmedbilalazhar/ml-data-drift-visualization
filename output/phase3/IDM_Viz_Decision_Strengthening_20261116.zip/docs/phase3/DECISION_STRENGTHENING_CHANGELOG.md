# Decision evaluation strengthening — 16 November 2026

The submitted Phase 2 remains authoritative and unchanged. No instructor feedback was received. This work is an outcome-informed extension of completed synthetic results.

## Implemented

- Exactly equal two/four-cohort label budgets across uniform, input, concern, combined and released-label audit policies, at delays 0/5/20; predecision label timing and explicit quota tail filling.
- Thresholds from all five original development seeds; final 30 seeds remain separate. `decision_strengthening_v1` used only the first development seed and is superseded by `decision_strengthening_v2`, retained intact.
- Paired 2,000-replicate seed bootstrap contrasts and complete per-seed/condition/decision CSVs. This measures audit allocation, not classifier adaptation, human benefit or episode-level utility.
- Consolidation of existing changed-marginal localization evidence. Known feature targets only for C1/C2. No new claim of causal or dependence localization.
- Exploratory persistence forecasts at h=0/1/5, with issue and target clocks and four comparators. These do not establish a general future-loss predictor or forecast intervals.
- Correct external historical source/reference class-count denominators in separate metadata; old monitoring results unchanged.
- Revised evidence view clearly marks unresolved source-calibrated estimates and horizon-zero scope, retaining release filters.
- Consolidated editable LaTeX/PDF report with new plots and preserved model/task and adaptation evidence. Large-seed findings remain pending and are not fabricated.

## Validation performed

- 81 whole-workspace tests passed in 10.56 seconds following the decision-policy changes, including three new information-timing/quota checks.
- Revised evidence view: 75,600 pure replay-logic release-boundary checks passed. This is not a browser usability study or full browser layout check.
- Report compiled using Tectonic 0.17.0. Rendered page contact sheets inspected; no overfull boxes or missing glyph warnings in corrected edition. Minor underfull paragraph/table spacing remains.
- Clean extracted scientific reruns and exact CSV comparisons are recorded in the supplementary archive's adjacent receipt, if completed. Do not infer success from this plan sentence.

## Unresolved limitations

Calibration transfer failure is exposed and communicated, not solved for arbitrary concept shift. Human evaluation and causal attribution remain deferred. Label-budget policy gains can depend on quota filling and the location/persistence of synthetic drift. All new comparisons were designed with knowledge of earlier outcomes. The external study is one dataset. The ongoing 1,500-seed study has its own lock and independent continuation.

## Reproduce

From workspace root with Anaconda scientific Python, use fresh directories:

```powershell
& C:/Users/hp/anaconda3/python.exe scripts/strengthen_phase3_decisions.py --out results/audit_NEW
& C:/Users/hp/anaconda3/python.exe scripts/evaluate_phase3_horizon_extension.py --out results/horizon_NEW
& C:/Users/hp/anaconda3/python.exe -m pytest tests -q
& ./tmp/tectonic/tectonic.exe reports/phase3/decision_strengthening_v3/REPORT.tex --outdir reports/phase3/decision_strengthening_v3 --keep-logs
```
