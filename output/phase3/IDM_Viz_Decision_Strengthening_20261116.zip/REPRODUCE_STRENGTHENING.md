# Decision and horizon evaluation supplement — prepared, not uploaded

This package adds outcome-informed label-audit policies, localization reporting,
persistence forecasting, corrected external class metadata and a consolidated
LaTeX/PDF report. It does not claim human benefit or general forecast validity.
The independently running 1,500-seed study is not included as completed evidence.

From this extracted root, using the recorded scientific environment:
  python -m pytest tests/phase3 -q
  python scripts/strengthen_phase3_decisions.py --out results/audit_NEW
  python scripts/evaluate_phase3_horizon_extension.py --out results/horizon_NEW

All outputs must be fresh. Compare results/audit_NEW CSVs to
results/phase3/decision_strengthening_v2 and results/horizon_NEW CSVs to
results/phase3/horizon_metadata_strengthening_v2. No classifier refits are needed.
The report source is reports/phase3/decision_strengthening_v3/REPORT.tex;
compile with Tectonic from the root, --outdir reports/phase3/decision_strengthening_v3.
Report regeneration reads earlier report prose not bundled here; compile the
included self-contained TeX and supplied figures directly instead.
