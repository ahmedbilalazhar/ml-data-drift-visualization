# IDM-Viz
## Phase 3: Research implementation and experimental evaluation
**Umar Behram (23I-2604) and Ahmed Bilal (23I-2581)**

Department of AI and Data Science, FAST-NUCES Islamabad

Data Analysis and Visualization | 15 November 2026 | Version 1

### Abstract
We implement an impact-aware monitoring prototype connecting input alarms, descriptive feature evidence, estimated accuracy, scheduled-label verification and a coordinated evidence view. The frozen logistic-classifier study comprises 210 paired-condition streams, 2,520,000 observations and 5,040 named batches across 30 seeds. Original-feature KS tests are combined with three frozen PCA coordinates; correctness calibration, Average Confidence and plug-in Poisson-binomial intervals provide a pre-label impact channel. Delays of 0, 5 and 20 batches reuse the same prediction caches.

The equally weighted mean accuracy-estimation MAE is 0.114 [0.113, 0.115] for calibrated AC and 0.113 [0.112, 0.114] for raw AC. These are seed-bootstrap intervals, not guarantees under arbitrary shift. The calibrated concern rule flags 169 of 5040 batches, with 160 correct flags, 9 incorrect flags and 1487 harmful batches unflagged. Overall coverage is 0.695, below the nominal .95 target. Conditional-only change is an intentional failure case. Integration preserves the calibrated-AC estimate exactly and does not create a more accurate estimator.

### Contribution and boundary
The contribution is a reproducible, label-safe implementation and controlled comparison. It is not evidence of causal explanation, successful adaptation, improved human decisions or real-world transfer. The implementation follows the submitted Phase 2 DOCX, narrowed by the previously prepared Phase 3 plan. No Phase 2 instructor feedback was received.

### Reading the evidence
Online evidence contains no current realised accuracy or F1. Label verification is recorded at its release clock. Evaluator-only files contain eventual truth for retrospective scoring. A missing concern flag is unresolved evidence, not a verdict of safety. The offline viewer filters truth by the selected as-of clock.


<!-- PAGE -->

# 1. Dataset, setup and frozen model
Each seed supplies disjoint samples of 4,000 training rows, 2,000 correctness-calibration rows, 2,000 historical reference rows and 12,000 monitoring rows per condition. The 24 monitoring batches contain 500 rows each. Development seeds are 90001-90005; the final seeds are 100-129. No final seed was replaced, dropped or selected from outcomes. Conditions share Gaussian innovations and label uniforms within seed, creating pairing rather than extra replications.

Eight baseline inputs are generated from independent standard-normal innovations Z. Set X0=Z0, X1=.3 Z0+sqrt(1-.3^2) Z1, and retain the other coordinates. Given the modified inputs, sample Y using p=sigmoid(1.2 X0-.9 X1+.6 X2). All values are finite numeric data; no imputation or one-hot encoding is required. This is a transparent controlled generator, not a reproduction of STAGGER, Agrawal or the reviewed Gaussian-mixture experiments.

| ID | Condition | Intervention |
| --- | --- | --- |
| C0 | Stationary | No intervention |
| C1 | Nuisance mean | X7 + 1.5 after row 4000 |
| C2 | Predictive mean | X0 ramp +0 to +1.5, rows 4001-6000 |
| C3 | Abrupt conditional | p becomes 1-p after row 4000 |
| C4 | Gradual conditional | Mixture of p and 1-p over rows 4001-6000 |
| C5 | Recurring conditional | 1-p on rows 4001-8000; then return |
| C6 | Dependence | Correlation X0/X1: .3 to .9; unit marginals |

StandardScaler, LogisticRegression(C=1, max_iter=500), three-component PCA and MiniBatchKMeans(k=3, n_init=3, batch_size=256) are fitted only on training rows. The logistic model and all representations are frozen. Correctness isotonic regression is fitted only on calibration rows, using raw confidence max(p_model,1-p_model) and the original model's correctness indicator. Class decisions remain p_model >= .5 after calibration. An ATC-style threshold is selected on the same calibration partition. The complete 2,000-row reference supplies historical realised accuracy; its final 1,000 inputs are the fixed input-test reference.

For C6, X1=.9 Z0+sqrt(1-.9^2) Z1 after onset, so Var(X1)=.9^2+(1-.9^2)=1 and Cov(X0,X1)=.9. This fixes the legacy correlated-coordinate rotation, which changed marginal variances. C6 has no changed marginal features. A dependence change can still change the distribution of a linear PCA coordinate.

Hardware: i7-10610U laptop, approximately 32 GB RAM. The scientific environment is Anaconda Python 3.13.5, NumPy 2.1.3, SciPy 1.17.0, scikit-learn 1.8.0, pandas 2.3.3 and matplotlib 3.10.8. Numerical thread pools are limited to one. No external dataset download or GPU is required.


<!-- PAGE -->

# 2. Monitoring, targets and clock contract
For each batch, compute two-sided KS tests on eight original inputs and three frozen PCA coordinates. Holm correction at .05 is applied to the 11-test family. An alarm means at least one rejection. The original-only ablation recomputes Holm over eight tests at the same level; its multiplicity allocation is therefore different. Per-batch control is not a lifetime false-alarm guarantee. SciPy method="auto" is used and warnings are recorded.

Feature evidence ranks the eight marginal KS distances. Ranking alone does not flag a feature; flags require a rejection in the declared family. Three frozen clusters show sample counts, occupancy and mean estimated correctness. Cluster rates below 20 observations are suppressed. Cluster summaries are descriptive, with no generating-region truth or cluster-localization accuracy claim.

For confidence s_i=max(p_i,1-p_i), the frozen isotonic correctness map gives q_i=g(s_i). Estimated accuracy is mean(q_i). A dynamic program computes the complete distribution of K=sum_i Bernoulli(q_i): P_j(k)=(1-q_j)P_(j-1)(k)+q_j P_(j-1)(k-1). The .025 and .975 quantiles divided by 500 form a plug-in prediction interval for realised batch accuracy. Independence and valid target correctness probabilities are required. Calibration-parameter uncertainty is omitted.

Historical accuracy A_ref is one observed reference proportion. The verification target is H=1{A_ref-A_batch>.05}; this is realised deterioration, not certified expected-population harm. Concern is P_plugin(K/500 < A_ref-.05); a score >=.95 flags high proxy concern. Its integer cutoff is evaluated using exact rational arithmetic. The point ablation instead flags A_ref-A_hat>.05. The concern score is not a calibrated probability certificate of harm under arbitrary shift.

### Information flow
Training features and labels -> frozen artifacts -> current features and IDs -> persisted predictions and online evidence -> scheduled released labels -> verified accuracy, macro-F1 and harm -> retrospective evaluator.

At input-completion clock t, prediction persistence is phase 0 and due label verification is phase 1. Labels for cohort t become available at t+d. Delay zero still predicts before observing labels. After input batch 24, the clock drains through 24+d without inventing input batches. Prediction and label IDs must agree exactly. Feature-only scoring accepts neither labels nor a broker handle. The broker is an API boundary, not a cryptographic sandbox.

### Matched comparators
Calibrated AC alone is an identity baseline for IDM's impact channel. Raw AC removes calibration while preserving classes. ATC-style estimation freezes a raw-confidence threshold matching calibration accuracy, with ties toward the larger threshold. The historical-accuracy constant is a no-change baseline. Original-feature KS is evaluated natively as an input detector and separately as a harm proxy. Released-label verification is an identity check available only after release, not a perfect early predictor.


<!-- PAGE -->

# 3. Coordinated evidence and delayed verification
![Coordinated as-of evidence](figures/01_coordinated_evidence.png)

Figure 1. The predeclared display example uses the smallest final seed (100), abrupt conditional change C3, delay 5 and as-of clock 16. The same batch axis coordinates adjusted-p input evidence, marginal feature distances, accuracy estimates and the release schedule. Only cohorts 1-11 can have verified accuracy at this clock. Cohorts 12-16 have proxy evidence only; future input batches are shaded. No eventual-truth line is presented as live evidence. The heatmap uses KS distances, separately from the p-value cutoff.

| Delay | Verified at t=24 | Unresolved at t=24 | Verified after drain | Harmful known at t=24 |
| --- | --- | --- | --- | --- |
| 0 | 5040 | 0 | 5040 | 1647 |
| 5 | 3990 | 1050 | 5040 | 1224 |
| 20 | 840 | 4200 | 5040 | 14 |

The delays change evidence availability, not a cohort's frozen predictions, estimates, eventual accuracy or harm. All released verification rows agree across delays. The 15,120 delayed verification rows represent 5,040 cohorts, not 15,120 independent batches. Labels are available for all observations after drainage; selective labelling is outside this experiment.

The standalone offline evidence view includes seed, condition, delay, as-of clock and shared-cohort controls. Feature rankings and cluster counts refer to that same selected batch. Its file contains retrospective release data for replay; the display hides unreleased truth. This is an implementation consistency demonstration, not a privacy mechanism or an analyst study.


<!-- PAGE -->

# 4. Input detection and descriptive localization
The native input-event denominator includes C1, C2 and C6 only. The first alarm within batches 9-12 matches the onset (a four-batch window); delay zero means the first affected batch. Misses and additional alerts are reported separately. Conditional-only C3-C5 are not native input-change events. Null burden uses all stationary C0 batches and the first eight batches in other conditions. Shared pre-onset draws mean these null estimates are paired, not independent samples across conditions.

| Condition | Full matches | Delay | Null /1000 | Original matches | Delay | Null /1000 |
| --- | --- | --- | --- | --- | --- | --- |
| C0 | not an input event | undefined | 48.6 | not an input event | undefined | 58.3 |
| C1 | 30/30 | 0.000 | 45.8 | 30/30 | 0.000 | 54.2 |
| C2 | 30/30 | 0.433 | 45.8 | 30/30 | 0.367 | 54.2 |
| C3 | not an input event | undefined | 45.8 | not an input event | undefined | 54.2 |
| C4 | not an input event | undefined | 45.8 | not an input event | undefined | 54.2 |
| C5 | not an input event | undefined | 45.8 | not an input event | undefined | 54.2 |
| C6 | 8/30 | 1.375 | 45.8 | 4/30 | 0.750 | 54.2 |

Detection delay is averaged only over matched events; it must be interpreted with the match fraction. Both detectors match all 30 C1 and all 30 C2 events. Full KS/PCA matches only 8/30 dependence events versus 4/30 for original KS. This limited gain does not establish reliable dependence detection. Stationary burden is 48.6/1000 batches for full KS/PCA and 58.3/1000 for original KS. Repeated alerts contribute to burden and are not additional successes.

| Condition | Changed marginal count | Precision@1 | Recall@3 | False feature flags |
| --- | --- | --- | --- | --- |
| C1 | 1 | 1.000 | 1.000 | 27 |
| C2 | 1 | 0.988 | 0.994 | 20 |
| C6 | 0 | undefined | undefined | 18 |

Localization rows above use all post-onset batches, including gradual-transition batches. C1's marginal truth is {X7}; C2's is {X0}. C6's changed-marginal set is empty, so its ranking precision and recall are undefined, while false marginal flags remain countable. No X0/X1 marginal truth is assigned merely because correlation changed. KS ranking evidence is descriptive association, not causal responsibility.

Cluster views are not scored against generating-cluster truth, because the generator does not have such regions. They do not feed the impact estimator. Removing a cluster panel would therefore not establish an accuracy contribution or an effect on human decisions.


<!-- PAGE -->

# 5. Accuracy estimation against eventual truth
![Accuracy estimation comparison](figures/02_estimation_mae.png)

Figure 2. Each dot is a complete seed's 24-batch MAE for one condition. Squares and bars show the mean and 2,000-replicate seed-bootstrap interval. Conditions, batches, ablations and delays are not treated as independent replications. The stationary and conditional-change cases expose different questions; an overall average should not hide that distinction.

| Condition | Calibrated AC / IDM | Raw AC | ATC-style | Historical |
| --- | --- | --- | --- | --- |
| C0 | 0.017 | 0.016 | 0.023 | 0.019 |
| C1 | 0.017 | 0.016 | 0.023 | 0.019 |
| C2 | 0.016 | 0.015 | 0.039 | 0.063 |
| C3 | 0.303 | 0.303 | 0.304 | 0.303 |
| C4 | 0.266 | 0.267 | 0.267 | 0.266 |
| C5 | 0.160 | 0.159 | 0.164 | 0.161 |
| C6 | 0.019 | 0.017 | 0.074 | 0.057 |

The equally weighted overall calibrated-AC MAE is 0.114 [0.113, 0.115]. The raw-AC value is 0.113 [0.112, 0.114]. Calibration changes overall MAE by +0.000802 accuracy units and provides no overall improvement here. Logistic regression is well matched to the generating label law; an isotonic fit on 2,000 historical observations can add estimation variation. This explanation is consistent with the design, not a separately tested mechanism. The calibrated-AC-alone and no-latent impact channels are exactly identical to full IDM.

Under conditional change, the same input distribution and frozen confidence values can accompany a reversed label law. Both input monitoring and confidence-only estimates can fail. Covariate shifts do not inherently imply harm: the unchanged generating label rule in C1/C2 does not guarantee unchanged realised model accuracy. All observed harm is evaluated against the same historical margin.


<!-- PAGE -->

# 6. Uncertainty, concern flags and failure cases
![Coverage and width](figures/03_coverage_width.png)

Figure 3. Coverage is the fraction of realised named-batch accuracies inside the plug-in interval. Width is reported alongside it. The .95 line is a target, not a certified property. Bootstrap intervals describe seed variation. Conditional-only shifts deliberately violate the interpretation of frozen source-calibrated correctness probabilities.

| Condition | Harmful | Flagged | TP | FP | FN | Precision | Recall |
| --- | --- | --- | --- | --- | --- | --- | --- |
| C0 | 11 | 0 | 0 | 0 | 11 | undefined | 0.000 |
| C1 | 11 | 0 | 0 | 0 | 11 | undefined | 0.000 |
| C2 | 6 | 0 | 0 | 0 | 6 | undefined | 0.000 |
| C3 | 485 | 0 | 0 | 0 | 485 | undefined | 0.000 |
| C4 | 473 | 0 | 0 | 0 | 473 | undefined | 0.000 |
| C5 | 247 | 0 | 0 | 0 | 247 | undefined | 0.000 |
| C6 | 414 | 169 | 160 | 9 | 254 | 0.947 | 0.386 |

These counts use all 720 batches per condition once, without delay duplication. The calibrated rule flags no C3-C5 batches, despite their many harmful outcomes. All 169 concern flags occur in C6: 160 are correct, 9 are incorrect, and 254 harmful C6 batches are missed. Overall coverage is 0.695 for calibrated AC and 0.725 for raw AC; the intervals fail strongly under conditional change. Precision is undefined with zero flags, and recall is undefined with zero harmful batches. Seed-level CSVs preserve these missing values and their denominators.

Frozen calibration uncertainty and the sampling uncertainty in A_ref are not included in the plug-in distribution. Reusing a historical reference also correlates batch-level harm targets. Accuracy is the primary target; class counts and macro-F1 are provided descriptively. Per-seed adaptive correctness-calibration error uses 20 equal-count bins and is stored separately for pre/post regimes. It is an empirical diagnostic, not proof of calibration.


<!-- PAGE -->

# 7. Ablations and paired comparisons
![Component ablations](figures/04_ablations.png)

Figure 4. Calibration removal changes correctness probabilities but preserves class predictions. Latent removal recomputes the original-feature family correction while leaving impact unchanged. Interval removal uses the point rule rather than the .95 concern rule; its interval coverage is not applicable. Fewer warnings alone do not demonstrate improvement.

| Variant | Flags | Correct flags | Incorrect flags | Harmful unflagged |
| --- | --- | --- | --- | --- |
| IDM_calibrated_AC | 169 | 160 | 9 | 1487 |
| raw_AC_no_calibration | 94 | 92 | 2 | 1555 |
| no_latent_same_impact | 169 | 160 | 9 | 1487 |
| point_rule_no_interval | 432 | 381 | 51 | 1266 |

| Comparator | Paired MAE difference: calibrated minus comparator [95% bootstrap] |
| --- | --- |
| raw_AC_no_calibration | 0.001 [-0.000, 0.002] |
| ATC_style | -0.014 [-0.015, -0.013] |
| constant_historical | -0.013 [-0.014, -0.011] |

Differences are first computed within seed and condition, then equally averaged across conditions for each seed before resampling. Positive differences favor the comparator. These are descriptive approximate intervals; there is no manufactured cross-dataset significance ranking. Complete paired vectors and per-condition intervals are supplied.

The runtime panel sums measured component costs from shared-cache runs. It is not a separately timed end-to-end variant benchmark. The point-rule bar excludes the Poisson-binomial recurrence; its small mean-comparison overhead is not separately measured. Full runs compute both raw and calibrated distributions for ablation reuse. Input scoring and prediction costs are counted once per variant estimate. Changing the number of tests also changes multiplicity allocation.


<!-- PAGE -->

# 8. Relation to research and methodological changes
Kivimaki et al. [1] analyze AC and Poisson-binomial accuracy intervals under calibration, using synthetic binary-classification experiments under covariate shift. We retain that estimator, freeze a correctness-calibration map without changing predictions, and evaluate conditional-only failures explicitly. Our generator, feature count, learner grid and sampling protocol differ, so published scores are not a comparable leaderboard. AC alone equals our impact channel; integration is the contribution, not a novel accuracy estimator.

Garg et al. [2] propose threshold-based performance prediction. Our ATC-style comparator matches calibration accuracy with a frozen raw-confidence threshold; its candidate endpoints and tie rule are explicit. This is an adaptation, not a complete reproduction of the original experiments. Greco et al. [3] monitor deep representations; our PCA plus coordinate KS procedure is not DriftLens or its Frechet-distance method.

SciPy's KS documentation [4] describes a two-sample continuous-distribution test and automatic exact/asymptotic selection. Scikit-learn guidance [5] motivates evaluating calibration separately. Installed versions, recorded in environment.json, govern execution. We make no numerical superiority claim over unreproduced literature methods and do not repeat Phase 2's absolute novelty assertion.

| Submitted Phase 2 element | Implemented treatment and unanswered scope |
| --- | --- |
| Five connected layers | Retained: input, description, impact, evidence view, verification status |
| Neural concept anchor | Frozen 3-component PCA; no CADD reproduction claim |
| Causal graphs / four causal types | Marginal KS screening only; causal questions deferred |
| Future harm / upper probability bound | h=0 realised batch target; explicitly plug-in concern |
| Online recalibration / error ADWIN | Frozen calibration; direct released-label verification |
| Adaptation / selective labels | Deferred; full delayed labels, zero retraining updates |
| Multiple natural/benchmark datasets | One controlled Gaussian-logistic generator family |
| 20-person interface study | Deferred; no participants or human-benefit result |
| Friedman / Nemenyi ranking | Paired seed differences and approximate seed bootstrap |

No instructor feedback was received, and these are team scope changes. RQ1 is partly addressed for current-batch harm and delayed verification. RQ2 is limited to descriptive marginal evidence and a latent detection ablation. RQ3 remains unanswered. RQ4 covers seven controlled regimes of one family; independent seeds do not demonstrate transfer to another task or real deployment.


<!-- PAGE -->

# 9. Validation, cost and reproduction
The final run passed validation for 210 streams, 5,040 cohorts and 2,520,000 instance-level joins. All queues drained; saved arrays verify calibrated-AC identity, delay invariance and absence of online truth columns. An independent complete 30-seed reproduction matched exactly across 21 scientific CSVs and 2,400 arrays (33,010,080 values); elapsed timings were excluded. The saved test log records 39 passing tests. The browser audit passed 488,880 release-boundary checks. These checks establish implementation consistency, not every scientific assumption.

| Measured stage | Total seconds |
| --- | --- |
| fit_seconds | 1.71 |
| prediction_seconds | 8.48 |
| original_ks_seconds | 112.87 |
| latent_ks_seconds | 47.12 |
| calibrated_impact_seconds | 49.84 |
| raw_impact_seconds | 50.00 |
| cluster_seconds | 4.32 |

Final runner elapsed time: 430.51 seconds, including scoring, cache compression, output writing and label replay. Windows process peak working set at completion: 241.6 MiB; it is not machine-wide peak RAM. Figure/report-source and PDF-rendering costs are stored separately; aggregation elapsed time was not instrumented. Component times overlap total score time and must not be added to that total again. The old feasibility probe is excluded from results.

### Reproduction
From the repository root, use the documented Anaconda executable. Run the scientific tests, create a fresh final output directory, evaluate its CSVs, then build the figures and report. The supplied README includes exact PowerShell commands and a full independent-reproduction comparison. Existing output directories are refused rather than overwritten. The locked manifest, source hashes, package versions and complete seed vectors accompany the data. Seeds and stage namespaces regenerate features; cached prediction arrays and evaluator labels enable audits.

### Remaining limitations
Only one well-specified logistic task and one learner are evaluated. Calibration can decay under both covariate and conditional shift. The PCA anchor can miss dependence directions; KS ranks are not causes. The .05 historical margin is an observed-reference target and the .95 concern threshold is not a validated harm probability. There is no online adaptation, selective-label analysis, external domain validation, causal evaluation or human study. Delay creates an evidence gap and does not repair the confidence estimator. Implementation and integrity evidence address a narrowed Phase 3 scope, not the entire original proposal.

### References (verified primary sources)
[1] J. Kivimaki et al. Confidence-based Estimators for Predictive Performance in Model Monitoring. JAIR 82, 2025. DOI: 10.1613/jair.1.16709. Author text: https://arxiv.org/html/2407.08649v2

[2] S. Garg et al. Leveraging Unlabeled Data to Predict Out-of-Distribution Performance. 2022. https://arxiv.org/abs/2201.04234

[3] S. Greco et al. Unsupervised Concept Drift Detection from Deep Learning Representations in Real-time. TKDE, 2025. https://arxiv.org/abs/2406.17813

[4] SciPy. ks_2samp API reference. https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.ks_2samp.html

[5] Scikit-learn. Probability calibration. https://scikit-learn.org/stable/modules/calibration.html
