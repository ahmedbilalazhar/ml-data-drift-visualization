# IDM-Viz Phase 3 weakness disposition - 16 November 2026

This register updates the Phase 2 traceability and existing v5 report with the 16 November extensions. It is not a claim that every submitted Phase 2 ambition is complete. The submitted Phase 2 DOCX, implementation brief and pre-deadline archive remain byte-for-byte preserved. No instructor feedback was received.

## Weaknesses with new implementation or evidence

| Weakness | Work completed | What the evidence supports | What it still does not support |
|---|---|---|---|
| Current labels were read before delayed release by the old runner | Frozen online/evaluator split, cached predictions, release clocks and no-truth online schemas; delay 0/5/20 core replay and delay-100 availability audit | Timing and output separation pass tests and clean-extraction checks | The package is a research simulation, not a production security boundary |
| Dependence generator accidentally changed marginals and C6 had weak sensitivity | Correct unit-marginal C6, plus targeted max-correlation-change detector with independent development/final seeds | C6 detection 30/30 versus 16/30 by KS/PCA in 30 held-out seeds | Higher stationary alarms (1.70 vs 0.83 per 24 batches); one synthetic dependence intervention only |
| Small Monte Carlo seed count | Existing 1,500-seed-per-task replication, plus fresh targeted C6 seeds | Reduced Monte Carlo uncertainty within the frozen synthetic laws | Cannot create independent natural domains or identify arbitrary-shift accuracy |
| One external dataset and one historical split/model | UCI Gas Sensor six-split/two-model/two-history sensitivity; second ELEC2 stream evaluation | Split, learner and history-window dependence are now measured on Gas Sensor; pipeline is exercised on a second dataset | Two datasets do not establish general domain transfer. ELEC2 has no known drift-onset labels and its reconstructed normalized-date ties are approximate |
| External interval used a normal approximation | Exact Poisson-binomial versus normal comparison on the same cached Gas Sensor predictions | Exact intervals were slightly narrower (mean 0.0234 vs 0.0258); both covered 0/9 | Approximation was not the calibration failure. The plug-in assumptions and coverage problem remain |
| No release delay 100 evidence | Availability-only replay at delay 100 | 0/5,040 cohort labels available by input end; all released by clock 124 | No delay-100 accuracy or adaptation result |
| No calibration-family comparison under delay | Matched-budget frozen isotonic, cumulative isotonic, and cumulative Platt-style recalibration on ELEC2 at delays 0/5/20 | Release clocks and training budgets match; both updated methods reduce signed bias | Neither update lowers MAE or ECE at any delay; coverage remains weak/mixed on one stream. See the TeX addendum and evaluator receipt |
| No prospective future-harm evaluation | Locked five-batch synthetic target, 30 development and 30 held-out seeds, time/unlabeled/released-label models and heuristic comparators | Held-out Brier improved from 0.231 time-only to 0.166 unlabeled and 0.149 with available released labels; paired whole-seed bootstrap favors each added evidence set | Predictive skill is within the same seven known synthetic laws only; no natural-stream transfer or action benefit |

## Unresolved weaknesses and why the evidence is insufficient

| Weakness | Current status | Evidence required for a valid resolution |
|---|---|---|
| Causal feature graph, causal drift type or responsibility | Not implemented. KS rankings, clusters and max-correlation pairs are descriptive | A defensible causal identification strategy or designed interventions with validated structural assumptions. A feature alarm alone cannot identify cause |
| Analyst benefit of coordinated views | No human-subject experiment | Approved recruitment, real participants, counterbalanced tasks, measured decisions, predeclared analysis and consent. No participants or results are fabricated |
| General future-harm prediction | Prospective five-batch forecast now tested on seeds held out from fitting, alongside persistence-style and prevalence heuristics | Independent natural streams or unseen intervention families, calibrated forecast intervals with coverage under shift, and held-out validation by domain/time |
| Accuracy identification under arbitrary conditional shift | Fundamentally not identifiable from unlabeled inputs alone; Gas Sensor and ELEC2 outcomes expose transfer failures | Explicit assumptions, prospective released labels or a valid domain adaptation design. More seeds or different plots cannot solve identifiability |
| Calibrated harm probability or certified population bound | Concern score is a plug-in Poisson-binomial probability with q treated as known | Coverage studies that include calibrator/reference uncertainty, dependence and shift; an explicit target population and valid sampling assumptions |
| Selective-label bias correction and operational audit usefulness | Equal-label-budget audit allocation is evaluated synthetically; selected labels do not validate nonselected groups | A prospective sampling design with known inclusion probabilities, positivity checks, estimator comparison and realistic acquisition costs |
| Faithful named literature baselines | KS/PCA, ATC-style, persistence and internal baselines exist; named DriftLens/Domino/ADWIN-U/benchmark methods are not reproduced | Protocol-fidelity implementation, same data splits and label budgets, verified settings, and source-backed numerical comparisons. Simplified detectors must be labeled as inspired/style baselines |
| Human, financial and deployment cost | Only row-label budgets and limited runtime are reported | Real operational measurement; cost and workload cannot be inferred from synthetic CPU timing |
| Broad adaptation comparison | A cumulative logistic refit study and recalibration diagnostic exist, but they are selected scenarios and have unequal information histories | Multiple adaptation policies under common data, label, compute and retraining budgets, across independent streams and delays |

## Current scientific claim boundary

The strengthened artifact supports a bounded claim: IDM-Viz now has label-safe feature monitoring, descriptive localization, calibrated current-cohort correctness estimates, exact plug-in impact intervals, delayed verification, a coordinated view, controlled synthetic evidence, two external-data exercises, and reproducible sensitivity analyses. The evidence also shows failures: dependence sensitivity costs alarm burden, external calibration can fail severely, exact intervals do not repair it, and delayed isotonic recalibration did not reduce estimation MAE on the tested ELEC2 sequence. No causal, human-benefit, future-risk-certification or broad-transfer claim is supported.

Reproduction and full outcome paths are recorded in `PHASE2_TRACEABILITY.md`, `ELEC2_TEMPORAL_EXTENSION_20261116.md`, `ELEC2_DELAYED_RECALIBRATION_20261116.md`, `FUTURE_HARM_FORECAST_EXTENSION_20261116.md`, `UCI224_SPLIT_MODEL_SENSITIVITY_20261116.md`, and `UCI224_EXACT_INTERVAL_EXTENSION_20261116.md`.
