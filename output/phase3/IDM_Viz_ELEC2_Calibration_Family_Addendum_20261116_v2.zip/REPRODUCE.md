# ELEC2 matched-budget calibration-family addendum

This small supplementary archive builds on the independently validated parent Phase 3 package v13 (hash in PRESERVATION.json). It adds a matched-budget comparison of frozen isotonic, cumulative isotonic and cumulative Platt-style calibration on the same 55-batch ELEC2 stream. It is an exploratory negative mitigation result, not a general calibration claim.

The Phase 2 submitted DOCX and pre-deadline archive are preserved unchanged. No external upload or submission is made.

Reproduce with `C:/Users/hp/anaconda3/python.exe` from the extracted root:
  python scripts/run_elec2_platt_recalibration.py --run results/phase3/elec2_temporal_20261116_v2 --out results/platt_NEW
  python scripts/evaluate_elec2_platt_recalibration.py --run results/phase3/elec2_temporal_20261116_v2 --platt results/platt_NEW --isotonic results/phase3/elec2_recalibration_20261116_v1 --out results/calibration_NEW
  python scripts/report_elec2_calibration_family.py --run results/phase3/elec2_temporal_20261116_v2 --platt results/platt_NEW --isotonic results/phase3/elec2_recalibration_20261116_v1 --results results/calibration_NEW --out reports/calibration_NEW
  python -m pytest tests/phase3/test_elec2_platt_recalibration.py -q

Protocol and interpretation boundary: docs/phase3/ELEC2_CALIBRATION_FAMILY_EXTENSION_20261116.md. The adjacent JSON receipt records exact clean-extraction checks.
