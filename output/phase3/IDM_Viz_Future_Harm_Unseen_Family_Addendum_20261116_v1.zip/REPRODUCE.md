# Future-harm held-out synthetic-family addendum

This supplement builds on main Phase 3 archive v13 (preserved by hash). It includes the original aligned-onset C7 pilot and a balanced-onset follow-up, both using 30 disjoint evaluation seeds and an unchanged model trained only on the original C0-C6 development set. The pilot's near-perfect time-only AUC is retained as a confound warning. The balanced follow-up still shows time predictability and is not external or general family validation.

From the extracted root run:
  python scripts/run_future_harm_unseen_family.py --onset-policy fixed9 --out results/fixed_NEW
  python scripts/evaluate_future_harm_unseen_family.py --run results/fixed_NEW
  python scripts/run_future_harm_unseen_family.py --onset-policy balanced_onsets --out results/balanced_NEW
  python scripts/evaluate_future_harm_unseen_family.py --run results/balanced_NEW
  python scripts/report_future_harm_unseen_family.py --run results/balanced_NEW --out reports/balanced_NEW
  python -m pytest tests/phase3/test_future_harm_unseen_family.py -q

All output folders must be new. Label-free predictor and evaluator truth artifacts are separate. The receipt beside this archive records exact clean-extraction matches and protected hashes.
