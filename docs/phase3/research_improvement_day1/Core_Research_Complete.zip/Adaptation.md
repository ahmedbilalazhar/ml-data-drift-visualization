# Released-label adaptation in controlled synthetic streams

**Ahmed Bilal (23I-2581) and Umar Behram (23I-2604)**  
Data Analysis and Visualization · Phase 3 supplementary experiment

**Status:** Outcome-informed exploratory add-on, protocol locked before its development and final runs.

## Question and scope

This small experiment asks whether cumulative refitting on labels after their scheduled release changes batch accuracy under two selected synthetic conditional changes: C3 (label-probability reversal with unchanged inputs) and X3 (XOR concept complement with unchanged inputs). Selection was informed by the earlier study's conditional-only failures and the extension's XOR task. The experiment is not external validation and is kept separate from the frozen-model results.

This final evidence uses 30 seeds per condition, 3 delays, and 24 batches of 500 rows. It created 60 feature streams, 180 delay streams, 8640 online method-batch records, 4,320,000 exact prediction/truth joins and 2,160,000 scheduled label rows.

## Locked comparison

Both arms use LogisticRegression(C=1, max_iter=500), training-only StandardScaler and the same initial 4,000 training rows. The frozen arm never updates. The adaptation arm refits on those training rows plus all unique monitoring labels available strictly before the next batch prediction. Calibration and reference partitions are not used for adaptation. No current or future label is passed to prediction; each batch's two prediction arrays are persisted before broker release, including delay zero.

At forecast batch `t` and delay `d`, the exact available monitoring-label count is `500 × min(24, max(0, t−d−1))`. At batch 24, delays 0, 5 and 20 make 11,500, 9,000 and 1,500 labels available before scoring; after drainage each releases the same 12,000 labels by clock 24+d. The frozen model is a zero-label update baseline, so gains versus it represent access-and-update effects. The only adaptive procedure is evaluated at exact, logged release budgets; no adaptive-method leaderboard is made.

The primary metric is paired-seed accuracy change over post-onset batches 9–24, with late post-onset batches 17–24 and pre-onset batches 1–8 shown separately. Macro F1 is secondary. Bootstrap intervals resample complete 30-seed vectors, never batches or delays. Shaded plot intervals use the same complete-seed-vector resampling.

## Results

| Condition | Delay | Regime | Adapted minus frozen accuracy, mean [seed-bootstrap 95% interval] | Seeds |
|---|---:|---|---:|---:|
| conditional reversal | 0 | late post | +0.0239 [+0.0197, +0.0287] | 30 |
| conditional reversal | 0 | post onset | +0.0002 [-0.0007, +0.0011] | 30 |
| conditional reversal | 0 | pre onset | +0.0002 [-0.0004, +0.0008] | 30 |
| conditional reversal | 5 | late post | +0.0003 [-0.0005, +0.0013] | 30 |
| conditional reversal | 5 | post onset | -0.0001 [-0.0009, +0.0007] | 30 |
| conditional reversal | 5 | pre onset | +0.0001 [-0.0003, +0.0004] | 30 |
| conditional reversal | 20 | late post | -0.0001 [-0.0005, +0.0002] | 30 |
| conditional reversal | 20 | post onset | +0.0000 [+0.0000, +0.0000] | 30 |
| conditional reversal | 20 | pre onset | +0.0000 [+0.0000, +0.0000] | 30 |
| XOR concept complement | 0 | late post | +0.0034 [-0.0020, +0.0091] | 30 |
| XOR concept complement | 0 | post onset | +0.0037 [-0.0017, +0.0096] | 30 |
| XOR concept complement | 0 | pre onset | -0.0026 [-0.0052, -0.0001] | 30 |
| XOR concept complement | 5 | late post | +0.0027 [-0.0016, +0.0075] | 30 |
| XOR concept complement | 5 | post onset | +0.0014 [-0.0028, +0.0058] | 30 |
| XOR concept complement | 5 | pre onset | -0.0000 [-0.0010, +0.0010] | 30 |
| XOR concept complement | 20 | late post | +0.0018 [+0.0002, +0.0035] | 30 |
| XOR concept complement | 20 | post onset | +0.0000 [+0.0000, +0.0000] | 30 |
| XOR concept complement | 20 | pre onset | +0.0000 [+0.0000, +0.0000] | 30 |

![Accuracy trajectories](adaptation_accuracy.png)

![Released-label budgets](label_budgets.png)

The table reports the measured paired difference; intervals crossing zero do not establish a directional effect. C3 and X3 remain generator-specific examples. Their different results do not prove that adaptation generally repairs delayed monitoring or confidence estimation.

In C3 at delay 0, late post-onset accuracy rose from 0.2755 frozen to 0.2995 adapted (paired difference +0.0239); however, across all post-onset batches the paired change was only +0.0002 [-0.0007, +0.0011]. At delays 5 and 20, the late-post differences were +0.0003 and -0.0001. For X3, late-post adapted accuracy stayed near 0.50 and differences ranged from +0.0018 to +0.0034; there was no meaningful overall post-onset improvement. This is limited recovery in one condition, not a general adaptation result.

At the batch-24 prediction, delays 0, 5 and 20 had 11,500, 9,000 and 1,500 labels available, of which 7,500, 5,000 and 0 came from post-onset batches. Thus delay 20 had no post-onset labels available to learn from by the final input prediction. The cumulative model also retains all pre-onset training examples. A plausible explanation for the weak X3 response is that a linear logistic boundary cannot represent the XOR interaction; the experiment did not directly test alternative nonlinear update mechanisms.

## Evidence separation and validation

An independent clean run matched 8 CSVs (17,682,084 cells) and 4,440 compressed arrays (21,840 arrays; 18,720,000 values) exactly. Timing and run-metadata fields were excluded.

`online_batches.csv` and per-batch prediction archives contain no outcome fields. `released_labels.csv` carries IDs and labels with availability clocks; `evaluator_truth/` is retrospective. The evaluator checked exact availability budgets before each fit, that no fitting label had an availability clock at or after its forecast, same-clock persistence ordering, identical release IDs across delays, exact prediction/truth joins, and drainage without new input. All metrics are evaluator-only. This is not a security boundary or human study.

## Limitations

This add-on studies one cumulative refit rule and one linear logistic model on two selected synthetic conditional-change cases. It does not add confidence calibration, prediction intervals, harm probabilities, or detector claims. The frozen comparison intentionally uses zero monitoring labels for fitting; only the availability schedules are shared. Cumulative retraining repeatedly reuses older released labels, so compute exposure differs from incremental training even though each adaptive run receives the same unique released IDs. No external data, natural onset labels, human participants, or analyst-benefit claims are present.

**Reproduction:** from the workspace root, run `powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\reproduce_phase3_adaptation.ps1 -RunDir results/phase3/adaptation_new_reproduction -ReportDir reports/phase3/adaptation_new_reproduction`. Use fresh, unused output directories. The wrapper evaluates the saved labels, checks exact equality with this final run, and renders the report. Exact Python package versions are in `environment.json`.
